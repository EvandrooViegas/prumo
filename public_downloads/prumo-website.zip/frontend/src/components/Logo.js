// Inline SVG logo recreating the PRUMO mark — gold helmet shield + wordmark
// Single component reused across header & footer.
export default function Logo({ variant = "light" }) {
  const wordColor = variant === "light" ? "#ffffff" : "#100b00";
  const subColor = variant === "light" ? "#dddddd" : "#100b00";
  return (
    <div className="flex items-center gap-3" aria-label="PRUMO Soalheiro, Lda.">
      <svg
        width="44"
        height="44"
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
      >
        <defs>
          <linearGradient id="prumoGold" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#f0c25a" />
            <stop offset="1" stopColor="#c8962e" />
          </linearGradient>
        </defs>
        {/* Shield */}
        <path
          d="M32 4 L58 14 V32 C58 47 46 56 32 60 C18 56 6 47 6 32 V14 Z"
          fill="url(#prumoGold)"
          stroke="#100b00"
          strokeWidth="2"
        />
        {/* Hard hat silhouette */}
        <path
          d="M20 36 H44 V40 H20 Z"
          fill="#100b00"
        />
        <path
          d="M22 36 C22 28 26 22 32 22 C38 22 42 28 42 36 Z"
          fill="#100b00"
        />
        <rect x="30" y="18" width="4" height="6" fill="#100b00" />
      </svg>
      <div className="leading-none">
        <div
          className="font-title text-[22px] tracking-wider"
          style={{ color: wordColor }}
        >
          PRUMO
        </div>
        <div
          className="text-[9px] font-bold tracking-[0.22em] mt-0.5"
          style={{ color: subColor }}
        >
          SOALHEIRO, LDA.
        </div>
      </div>
    </div>
  );
}
