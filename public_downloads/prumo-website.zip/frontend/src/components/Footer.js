"use client";

import Link from "next/link";
import Logo from "./Logo";
import { useLanguage } from "./LanguageProvider";

export default function Footer() {
  const { t } = useLanguage();
  return (
    <footer
      className="bg-brand-dark text-white"
      data-testid="site-footer"
    >
      <div className="container mx-auto px-6 lg:px-10 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <Logo />
        <div className="text-white/60 text-sm tracking-wider">
          @2026 — Kachica · {t.footer.rights}
        </div>
        <Link
          href="/orcamento"
          className="text-white text-sm font-bold tracking-[0.18em] uppercase border-b-2 border-brand-gold pb-1 hover:text-brand-gold transition-colors"
          data-testid="footer-contact-link"
        >
          {t.footer.contactUs}
        </Link>
      </div>
    </footer>
  );
}
